package com.example.smsspend

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var summaryView: TextView
    private lateinit var list: ListView
    private var data: List<Txn> = emptyList()

    private val cats = listOf(
        "Food Delivery", "Cafes & Tea", "Restaurants", "Groceries",
        "Fuel & Transport", "Pharmacy & Health", "Telecom", "Utilities",
        "Subscriptions", "Online Shopping", "Charity", "Transfers", "Income", "Other"
    )

    private val reqPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) refresh()
        else summaryView.text = "Permission denied. Enable SMS access in Settings > Apps."
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        summaryView = findViewById(R.id.summary)
        list = findViewById(R.id.list)
        findViewById<Button>(R.id.refresh).setOnClickListener { ensureAndRefresh() }
        list.setOnItemClickListener { _, _, pos, _ -> recategorize(pos) }
        ensureAndRefresh()
    }

    private fun ensureAndRefresh() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
            == PackageManager.PERMISSION_GRANTED
        ) refresh() else reqPerm.launch(Manifest.permission.READ_SMS)
    }

    private fun refresh() {
        val ov = Store.overrides(this)
        data = SmsParser.load(this).map { t -> ov[t.key]?.let { t.copy(category = it) } ?: t }
        list.adapter = TxnAdapter()
        renderSummary()
    }

    private fun isThisMonth(d: Long): Boolean {
        val c = Calendar.getInstance(); val now = Calendar.getInstance()
        c.timeInMillis = d
        return c.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
            c.get(Calendar.MONTH) == now.get(Calendar.MONTH)
    }

    private fun renderSummary() {
        val spend = data.filter { it.type == "debit" || it.type == "walletOut" }
        val byCat = HashMap<String, Double>()
        var monthTotal = 0.0
        for (t in spend) {
            byCat[t.category] = (byCat[t.category] ?: 0.0) + t.amount
            if (isThisMonth(t.date)) monthTotal += t.amount
        }
        val total = spend.sumOf { it.amount }
        val sb = StringBuilder()
        sb.append("Spent this month: ").append(String.format("%.3f", monthTotal)).append(" OMR\n")
        sb.append("Total tracked out: ").append(String.format("%.3f", total)).append(" OMR\n\n")
        val lines = StringBuilder()
        for ((c, a) in byCat.entries.sortedByDescending { it.value }) {
            sb.append(c).append(": ").append(String.format("%.3f", a)).append("\n")
            lines.append("• ").append(c).append("  ").append(String.format("%.1f", a)).append("\n")
        }
        summaryView.text = sb.toString().trim()
        Store.saveSummary(this, lines.toString().trim(), String.format("%.3f OMR", monthTotal))
        updateWidget(this)
    }

    private fun recategorize(pos: Int) {
        val t = data[pos]
        AlertDialog.Builder(this)
            .setTitle(t.merchant)
            .setItems(cats.toTypedArray()) { _, i ->
                Store.setOverride(this, t.key, cats[i]); refresh()
            }.show()
    }

    private inner class TxnAdapter : BaseAdapter() {
        val df = SimpleDateFormat("MM/dd", Locale.US)
        override fun getCount() = data.size
        override fun getItem(p: Int) = data[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_txn, parent, false)
            val t = data[p]
            v.findViewById<TextView>(R.id.merchant).text = t.merchant
            v.findViewById<TextView>(R.id.cat).text = t.category + "  ·  " + df.format(Date(t.date))
            val amt = v.findViewById<TextView>(R.id.amount)
            val sign = if (t.type == "deposit" || t.type == "walletIn") "+" else "-"
            amt.text = sign + String.format("%.3f", t.amount)
            return v
        }
    }

    companion object {
        fun updateWidget(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, SpendingWidget::class.java))
            for (id in ids) SpendingWidget.render(ctx, mgr, id)
        }
    }
}
