package com.example.smsspend

import android.content.Context
import org.json.JSONObject

object Store {
    private const val P = "smsspend"

    fun overrides(c: Context): MutableMap<String, String> {
        val s = c.getSharedPreferences(P, 0).getString("ov", "{}")!!
        val o = JSONObject(s)
        val m = HashMap<String, String>()
        for (k in o.keys()) m[k] = o.getString(k)
        return m
    }

    fun setOverride(c: Context, key: String, cat: String) {
        val m = overrides(c)
        m[key] = cat
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        c.getSharedPreferences(P, 0).edit().putString("ov", o.toString()).apply()
    }

    fun saveSummary(c: Context, text: String, total: String) {
        c.getSharedPreferences(P, 0).edit()
            .putString("wtext", text).putString("wtotal", total).apply()
    }

    fun summary(c: Context): Pair<String, String> {
        val sp = c.getSharedPreferences(P, 0)
        return Pair(sp.getString("wtotal", "—")!!, sp.getString("wtext", "Open app to load")!!)
    }
}
